package auca.ac.rw;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/UserValidationServlet")
public class UserValidationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String username = request.getParameter("username");
        String ageStr = request.getParameter("age");
        String favNumStr = request.getParameter("favoriteNumber");

        int age = Integer.parseInt(ageStr);
        int favoriteNumber = Integer.parseInt(favNumStr);

        if (username == null || username.trim().isEmpty()) {
            out.println("Please enter a valid username.");
        } else {
            
            if (age < 18) {
                out.println("Hello " + username + ", you are still a minor.<br>");
            } else {
                out.println("Hello " + username + ", you are adult.<br>");
            }

         
            if (favoriteNumber % 2 == 0) {
                out.println("Your favorite number " + favoriteNumber + " is even.");
            } else {
                out.println("Your favorite number " + favoriteNumber + " is odd.");
            }
        }

        out.close();
    }
}
